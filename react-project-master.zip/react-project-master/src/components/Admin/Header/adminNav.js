export const adminNav = [
  {
    name: "Dashboard",
    path: "/",
  },
  {
    name: "List",
    path: "/list",
  },
];
